package com.bhuvi.exceptions;

public class BusLinkException extends Exception{
	public BusLinkException() {
		// TODO Auto-generated constructor stub
	}
	
	public BusLinkException(String message) {
		super(message);
	}
}
